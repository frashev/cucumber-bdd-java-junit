public class MyException extends Exception{

    public void printException(){
        System.out.println("user defined exception!");
    }

}
