public class Employee {

    int base = 10000;

    int salary(){
        return base;
    }

    static String designation(){
        return "tester";
    }

}
