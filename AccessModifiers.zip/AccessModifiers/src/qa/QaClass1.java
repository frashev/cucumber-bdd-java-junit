package qa;

public class QaClass1 {

    public void myQaMethod1(){
        QaClass qaClass = new QaClass();
        qaClass.myMethod();
    }
}
